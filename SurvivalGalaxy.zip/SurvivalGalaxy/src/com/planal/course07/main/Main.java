package com.planal.course07.main;

import android.app.Activity;
import android.content.pm.ActivityInfo;
import android.content.res.AssetManager;
import android.graphics.Rect;
import android.os.Bundle;
import android.view.Display;
import android.view.KeyEvent;
import android.view.Menu;
import android.view.MotionEvent;
import android.view.Window;
import android.view.WindowManager;

public class Main extends Activity
{
	private static AssetManager am;
	private static final Rect RECT_GAMESCREEN = new Rect();
	private GameController gameController;
	@SuppressWarnings("deprecation")
	@Override
	protected void onCreate(Bundle savedInstanceState)
	{
		super.onCreate(savedInstanceState);
				
		setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);//��Ļˮƽ����
		
		requestWindowFeature(Window.FEATURE_NO_TITLE);//ȥ��������
		
		getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
				WindowManager.LayoutParams.FLAG_FULLSCREEN);//ȥ��������
		
		Display display = getWindowManager().getDefaultDisplay();
		
		@SuppressWarnings("deprecation")
		int niScreenWidth = display.getWidth();
		int niScreenHeight = display.getHeight();
		
		RECT_GAMESCREEN.left = ( niScreenWidth - Info.NI_SCREEN_WIDTH) / 2;
		RECT_GAMESCREEN.top = ( niScreenHeight - Info.NI_SCREEN_HEIGHT) / 2;
		RECT_GAMESCREEN.right = RECT_GAMESCREEN.left + Info.NI_SCREEN_WIDTH;
		RECT_GAMESCREEN.bottom = RECT_GAMESCREEN.top + Info.NI_SCREEN_HEIGHT;
		
		am = getAssets();
		
		gameController = new GameController(this);
		
		setContentView(gameController);
	}
	
	public static final int getScreenX(){return RECT_GAMESCREEN.left ;}
	public static final int getScreenY(){return RECT_GAMESCREEN.top ;}
	public static final int getScreenWidth(){return Info.NI_SCREEN_WIDTH ;}
	public static final int getScreenHeight(){return Info.NI_SCREEN_HEIGHT ;}
	public static final AssetManager getAssetManager(){return am;}
	

	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event)
	{
		gameController.onKeyDown(keyCode);
		return super.onKeyDown(keyCode, event);
	}

	@Override
	public boolean onTouchEvent(MotionEvent event)
	{
		gameController.onTouch(event);
		return super.onTouchEvent(event);
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu)
	{
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.main, menu);
		return true;
	}

}
