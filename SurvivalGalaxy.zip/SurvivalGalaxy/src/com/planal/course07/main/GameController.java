package com.planal.course07.main;

import com.planal.course07.game.Background;
import com.planal.course07.game.HScore;
import com.planal.course07.game.Player;
import com.planal.course07.game.Prop;
import com.planal.course07.game.PropCallback;
import com.planal.course07.game.PropManager;
import com.planal.course07.game.StartView;
import com.planal.course07.tools.Tools;

import android.app.Activity;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.media.MediaPlayer;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.SurfaceHolder;
import android.view.SurfaceView;

public class GameController extends SurfaceView implements SurfaceHolder.Callback, Runnable
{
	private SurfaceHolder surfaceHolder;
	private Background background;
	private Player player;
	private Bitmap bmpGameOver;
	private PropManager propManager;
	private HScore hScore;
	private StartView startView;
	private MediaPlayer mediaPlayer;
	
	private boolean isRunning;
	private boolean isGameOver;
	private boolean isStartView = true;

	public GameController(Context context)
	{
		super(context);
		startView = new StartView(new LoadResourceMonitor());
		surfaceHolder = getHolder();
		surfaceHolder.addCallback(this);
	}
	
	private void startGame()
	{
		isStartView = false;
		background.start();
		player.start();
		propManager.start();
		
		closeMusic();
		playMusic(R.raw.game);
	}

	public void restart()
	{
		background.reset();
		player.reset();
		propManager.reset();
		if(bmpGameOver != null)
			bmpGameOver = null;
		isGameOver = false;
		background.start();
		player.start();
		propManager.start();
		playMusic(R.raw.game);

	}
	
	private void playMusic(final int niMusicId)
	{
		new Thread(new Runnable()
		{	
			public void run()
			{
				try{Thread.sleep(500);}catch(Exception e){}
				mediaPlayer = MediaPlayer.create(getContext(), niMusicId);
				if(mediaPlayer!=null && mediaPlayer.isPlaying() == false)
				{
					mediaPlayer.setLooping(true);
					mediaPlayer.start();
				}
			}
		}).start();
	}
	
	private void closeMusic()
	{
		if(mediaPlayer!=null)
		{
			new Thread(new Runnable()
			{	
				public void run()
				{
					try{Thread.sleep(500);}catch(Exception e){}
					if(mediaPlayer.isPlaying())
					{
						try{mediaPlayer.stop();}catch(Exception e){}
						mediaPlayer.release();
						mediaPlayer = null;
					}
				}
			}).start();
		}
	}
	
	public void drawGame(Canvas canvas)
	{
		if(isStartView)
		{
			startView.onDraw(canvas);
		}
		else
		{
			if(isGameOver)
			{
				canvas.drawBitmap(bmpGameOver, 
						Main.getScreenX() + (Main.getScreenWidth() - bmpGameOver.getWidth()) / 2, 
						Main.getScreenY() + (Main.getScreenHeight() - bmpGameOver.getHeight()) / 2,
						null);
			}
			else
			{
				background.onDraw(canvas);
				player.onDraw(canvas);	
				propManager.onDraw(canvas);
				hScore.onDraw(canvas);
			}
		}
		
	}
	
	public void onTouch(MotionEvent event)
	{
		float nfTouchX = event.getX();
		boolean isLeft = nfTouchX < Main.getScreenX() + Main.getScreenWidth() / 2;
		switch(event.getAction())
		{
		case MotionEvent.ACTION_DOWN:
			if(!isGameOver && !isStartView)
				player.setState(true, isLeft);
			break;
		case MotionEvent.ACTION_UP:
			if(isStartView)
			{
				if(startView.isStartGameEnable())
					startGame();
			}
			else
			{
				if(!isGameOver)
					player.setState(false, isLeft);
				else
					restart();
			}
			break;
		}
	}
	
	public void onKeyDown(int keyCode)
	{

	}
	
	public void draw()
	{//����������������������������֮��ͬ��������Ϸ������
		if(surfaceHolder != null)
		{
			//����������ȡ�û���
			Canvas canvas = surfaceHolder.lockCanvas();
			if(canvas != null)
			{
				
				synchronized(surfaceHolder)
				{//ʵ��ͬ�����ܣ�������ƹ������̲߳�ͬ���Ļ����޷����л���
					drawGame(canvas);
				}
				//��������
				surfaceHolder.unlockCanvasAndPost(canvas);
			}
		}
	}
	
	@Override
	public void run()
	{
		while (isRunning) 
		{
			try{Thread.sleep(20);} catch (InterruptedException e){}
			draw();
		}
	}

	@Override
	public void surfaceChanged(SurfaceHolder holder, int format, int width,
			int height)
	{
		
	}

	@Override
	public void surfaceCreated(SurfaceHolder holder)
	{
		isRunning = true;
		new Thread(this).start();
		startView.start();
		if(isStartView)
			playMusic(R.raw.start);
		else
			playMusic(R.raw.game);

	}

	@Override
	public void surfaceDestroyed(SurfaceHolder holder)
	{
		isRunning = false;
		closeMusic();
	}

	private class StateMonitor implements StateCallback
	{	
		public void notityGameOver(int niScore)
		{
			closeMusic();
			hScore.updateHScore(getContext().getSharedPreferences(HScore.STR_SHARED_DATA, Activity.MODE_PRIVATE),niScore);
			background.close();
			player.close();
			propManager.close();
			bmpGameOver = Tools.readImage(Main.getAssetManager(), "system/gameover.png");
			isGameOver = true;
		}
	}
	
	private class PropMonitor implements PropCallback
	{
		public void collideCheck(Prop prop)
		{
			if(prop.isCollideWith(player.getRect()))
			{
				player.propDeal(prop.getType());
				prop.reset();
			}
		}
	}

	private class LoadResourceMonitor implements LoadResourceListener
	{

		public boolean loadResource()
		{
			hScore = new HScore(getContext().getSharedPreferences(HScore.STR_SHARED_DATA, Activity.MODE_PRIVATE));
			background = new Background();
			player = new Player();
			player.addStateListener(new StateMonitor());
			propManager = new PropManager(new PropMonitor());
			return true;
		}
		
	}
}
