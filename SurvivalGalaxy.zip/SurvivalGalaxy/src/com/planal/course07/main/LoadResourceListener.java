package com.planal.course07.main;

public interface LoadResourceListener
{
	boolean loadResource();
}
