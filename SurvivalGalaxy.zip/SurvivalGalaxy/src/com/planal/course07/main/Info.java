package com.planal.course07.main;

public interface Info
{
	int NI_SCREEN_WIDTH = 800;
	int NI_SCREEN_HEIGHT = 480;
	
}
