package com.planal.course07.main;

public interface StateCallback
{
	void notityGameOver(int niHScore);
}
