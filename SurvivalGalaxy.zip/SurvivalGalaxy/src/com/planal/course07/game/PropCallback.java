package com.planal.course07.game;

public interface PropCallback
{
	void collideCheck(Prop prop);
}
