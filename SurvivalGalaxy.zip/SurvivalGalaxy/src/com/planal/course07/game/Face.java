package com.planal.course07.game;

import com.planal.course07.tools.Tools;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Point;
import android.graphics.Rect;

public class Face
{
	private final int NI_FACE_MAX = 7;
	private final int NI_FACE_LENGTH = 8 ;
	
	private Bitmap[][] arrBmp;
	private Point point;
	
	private int niCurFace;
	private int niCurFaceIdx;
	private boolean isPlaying;

	public Face()
	{
		arrBmp = new Bitmap[NI_FACE_MAX][NI_FACE_LENGTH];
		for (int i = 0; i < NI_FACE_MAX; i++)
			arrBmp[i] = Tools.readBitmapFolderFromAssets("image/player/face/"+i);
		point = new Point();
	} 
	
	public void onDraw(Canvas canvas)
	{
		if(isPlaying && niCurFaceIdx < NI_FACE_LENGTH)
			canvas.drawBitmap(arrBmp[niCurFace][niCurFaceIdx], point.x, point.y, null);
	}
	
	public void start(int niFaceType,Rect rectPlayer)
	{
		niCurFace = niFaceType;
		niCurFaceIdx = 0;
		point.set(rectPlayer.left + (rectPlayer.right - rectPlayer.left - arrBmp[niCurFace][niCurFaceIdx].getWidth()) / 2,
				rectPlayer.top - arrBmp[niCurFace][niCurFaceIdx].getHeight());
		if(!isPlaying)
		{
			isPlaying = true;
			new Thread(new FaceAnimation()).start();
		}
	}
	
	private class FaceAnimation implements Runnable
	{
		public void run()
		{
			while(isPlaying)
			{
				try{Thread.sleep(40);} catch (InterruptedException e){}
				if(++niCurFaceIdx == NI_FACE_LENGTH)
				{
					isPlaying = false;
					break;
				}
			}
		}
	}
}
