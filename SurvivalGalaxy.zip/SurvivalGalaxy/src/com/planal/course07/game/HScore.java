package com.planal.course07.game;

import com.planal.course07.main.Main;

import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Point;

public class HScore
{
	public static final String STR_SHARED_DATA = "hScore";
	
	private String strHScore;
	private Paint paint;
	private Point point;
	
	private int niHScore;
	
	public HScore(SharedPreferences shared)
	{
		niHScore = shared.getInt(STR_SHARED_DATA, 0);
		
		strHScore = "��߷֣�" + niHScore ;
		
		paint = new Paint();
		paint.setTextSize(14);
		paint.setColor(Color.RED);
		paint.setAntiAlias(true);
		
		point = new Point(Main.getScreenX() + 10 , Main.getScreenY() + 10 + (int)paint.getTextSize());
	}
	
	public void onDraw(Canvas canvas)
	{
		canvas.drawText(strHScore, point.x ,point.y ,paint);
	}
	
	public boolean updateHScore(SharedPreferences shared, int niCurScore)
	{
		if(niCurScore > niHScore)
		{
			Editor editor = shared.edit();
			editor.putInt(STR_SHARED_DATA, niCurScore);
			editor.commit();
			niHScore = niCurScore;
			strHScore = "��߷�" + niHScore;
			return true;
		}
		return false;
	}
}
