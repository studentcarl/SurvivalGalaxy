package com.planal.course07.game;
import java.util.Timer;
import java.util.TimerTask;

import android.graphics.Canvas;
public class PropManager
{
	private final int NI_NUMBER_MAX = 20;
	private final int NI_ADD_PROP_TIME = 1000;
	
	private Prop[] arrProp;
	private PropCallback cb;
	private Timer timerAddProp;
	
	private boolean  isThread ;
	public PropManager(PropCallback cb)
	{
		this.cb = cb ; 
		arrProp = new Prop[NI_NUMBER_MAX];
	}
	
	public void onDraw(Canvas canvas)
	{
		for(int i=0;i < NI_NUMBER_MAX; i++)
			if(arrProp[i] != null)
				arrProp[i].onDraw(canvas);
	}
	
	public void logic()
	{
		for(int i=0;i < NI_NUMBER_MAX; i++)
			if(arrProp[i] != null)
				arrProp[i].logic();
	}
	
	public void reset()
	{
		for(int i=0;i < NI_NUMBER_MAX; i++)
			if(arrProp[i] != null)
				arrProp[i].reset();
	}
	
	public void start()
	{
		if(!isThread)
		{
			isThread = true;
			new LogicMotion().start();
		}
		
		if(timerAddProp == null)
		{
			timerAddProp = new Timer();
			timerAddProp.schedule(new AddProp(), 10, NI_ADD_PROP_TIME);
		}
	}
	
	public void close()
	{
		isThread = false;
		if(timerAddProp != null)
		{
			timerAddProp.cancel();
			timerAddProp = null;
		}
	}
	
	private class LogicMotion extends Thread
	{
		public void run()
		{
			while(isThread)
			{
				try{Thread.sleep(80);} catch (InterruptedException e){}
				logic();
			}
		}
	}

	private class AddProp extends TimerTask
	{
		public void run()
		{
			boolean isAddProp = false;
			for (int i = 0; i < NI_NUMBER_MAX; i++)
			{
				if(arrProp[i] != null && arrProp[i].isEnable())
				{
					arrProp[i].use();
					isAddProp = true;
					break;
				}
			}
			if(!isAddProp)
			{
				for (int i = 0; i < NI_NUMBER_MAX; i++)
				{
					if(arrProp[i] == null)
					{
						arrProp[i] = new Prop(cb);
						break;
					}
				}
			}
		}
	}
}
