package com.planal.course07.game;

import com.planal.course07.main.Main;
import com.planal.course07.tools.Tools;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Paint;

public class Background
{
	private final int NI_BACKGROUND_CHANCE_TIME = 1000 * 10 ;
	private final int NI_BACKGROUND_MAX = 3;
	
	private Bitmap[] arrBmpBackgrounds;
	private Paint paintBackground;
	
	private int niBackgroundId;
	private int niBackgroundAlphaId;
	private boolean isThread;
	private boolean isShowing;
	
	public Background()
	{
		arrBmpBackgrounds = new Bitmap[NI_BACKGROUND_MAX];
		for (int i = 0; i <NI_BACKGROUND_MAX; i++)
		{
			arrBmpBackgrounds[i] =Tools.readImage(Main.getAssetManager(), "image/background/"+i+".jpg");
		}
		paintBackground = new Paint();
		paintBackground.setAlpha(0);
	}
	
	public void reset()
	{
		if(niBackgroundId != 0)
			niBackgroundId = 0;
		if(niBackgroundAlphaId != 0)
			niBackgroundAlphaId = 0;
		if(paintBackground.getAlpha() != 0)
			paintBackground.setAlpha(0);
		isShowing = false;
	}
	
	public void onDraw(Canvas canvas)
	{
		canvas.drawBitmap(arrBmpBackgrounds[niBackgroundId], Main.getScreenX(),Main.getScreenY(), null);
		if (    isShowing     ) 
		{
			canvas.drawBitmap(arrBmpBackgrounds[niBackgroundAlphaId], Main.getScreenX(),Main.getScreenY(), paintBackground);

		} 
	}
	
	public void start()
	{
		if(!isThread)
		{
			isThread = true;
			new Thread(new LogicMonitor()).start();
		}
	}
	
	public void close()
	{
		isThread = false;
	}
	
	private class LogicMonitor implements Runnable
	{

		public void run()
		{
			while(isThread)
			{
				if ( isShowing ) 
				{
					int niAlpha = paintBackground.getAlpha();
					niAlpha++;
					if(niAlpha==255)
					{
						niBackgroundId = niBackgroundAlphaId;
						try{Thread.sleep(80);} catch (InterruptedException e){}
						paintBackground.setAlpha(0);
						isShowing = false;
					}
					else
					{
						paintBackground.setAlpha(niAlpha);
						try{Thread.sleep(80);} catch (InterruptedException e){}

					}
				} 
				else
				{
					try{Thread.sleep(NI_BACKGROUND_CHANCE_TIME);} catch (InterruptedException e){}
					niBackgroundAlphaId = ++niBackgroundAlphaId % NI_BACKGROUND_MAX;
					isShowing = true;

				}
			}
		}
	}
}
