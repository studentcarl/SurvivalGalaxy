package com.planal.course07.game;

import java.util.Timer;
import java.util.TimerTask;


import com.planal.course07.main.Main;
import com.planal.course07.main.StateCallback;
import com.planal.course07.tools.Tools;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Paint.Style;
import android.graphics.Point;
import android.graphics.Rect;

public class Player
{
	public static final int NI_HP_BAR_WIDTH = 600;
	
	private final int NI_LV_MAX = 3;
	private final int NI_FRAME_MAX = 6;
	private final int NI_SPEED_BASIC = 4;
	private final int NI_HP_BAR_HEIGHT = 6;
	private final int NI_HP_AUTO_HURT_ROTATE = 100;
	private final String STR_TEXT_LV = "Lv:";
	private final String STR_TEXT_SCORE = "Score��";
	
	private int[] arrNIHpColor = {Color.RED,Color.GREEN,Color.MAGENTA};
	private Bitmap[][] arrBmpAnimation;
	private Rect rectPosition;
	private Rect rectHpBar;
	private Paint paintHpBar;
	private Paint paintHpBarBorder;
	private Paint paintText;
	private Timer timerUpAutoHurt;
	private Point pScore;
	private Point pLv;
	private String strScore;
	private String strLv;
	private Face face;
	private StateCallback callback;
	
	private int niLv = 0;
	private int niScore;
	private int niFrame;
	private int niHp = NI_HP_BAR_WIDTH;
	private int niStopAutoHurtValue;
	private boolean isMoving;
	private boolean isLeft;
	private boolean isThread;
	
	public Player()
	{
		arrBmpAnimation = new Bitmap[NI_LV_MAX][NI_FRAME_MAX];
		for (int i = 0; i < NI_LV_MAX; i++)
			for (int j = 0; j < NI_FRAME_MAX; j++)
				arrBmpAnimation[i][j] = Tools.readImage(Main.getAssetManager(),"image/player/p"+(i+1)+"_"+j+".png");
		
		final int NI_WIDTH = arrBmpAnimation[niLv][niFrame].getWidth();
		final int NI_HEIGHT = arrBmpAnimation[niLv][niFrame].getHeight();
		
		rectPosition = new Rect();
		rectPosition.left = Main.getScreenX() + (Main.getScreenWidth() - NI_WIDTH)/2;
		rectPosition.top = Main.getScreenY() + Main.getScreenHeight() - (int)(NI_HEIGHT * 1.5);
		rectPosition.right = rectPosition.left + NI_WIDTH;
		rectPosition.bottom = rectPosition.top + NI_HEIGHT;
		
		rectHpBar = new Rect();
		rectHpBar.left = Main.getScreenX() + (Main.getScreenWidth() - NI_HP_BAR_WIDTH ) / 2 ;
		rectHpBar.top = Main.getScreenY() + Main.getScreenHeight() - NI_HP_BAR_HEIGHT - 4;
		rectHpBar.right = rectHpBar.left + NI_HP_BAR_WIDTH;
		rectHpBar.bottom = rectHpBar.top + NI_HP_BAR_HEIGHT;
		
		paintHpBar = new Paint();
		paintHpBarBorder = new Paint();
		paintHpBarBorder.setColor(Color.rgb(0, 255, 255));
		paintHpBarBorder.setStyle(Style.STROKE);
		paintHpBarBorder.setStrokeWidth(1);
		
		paintText = new Paint();
		paintText.setTextSize(11);
		paintText.setColor(Color.YELLOW);
		paintText.setAntiAlias(true);
		
		pLv = new Point(Main.getScreenX() + 5, Main.getScreenY() + Main.getScreenHeight() - 5);
		pScore = new Point(Main.getScreenX() + Main.getScreenWidth() - 5 - (int)paintText.measureText(STR_TEXT_SCORE + niScore), pLv.y);
	
		strScore = STR_TEXT_SCORE + niScore ;
		strLv = STR_TEXT_LV + (niLv + 1) ;
		
		face = new Face();
	}
	
	public void addStateListener(StateCallback callback)
	{
		this.callback = callback;
	}
	
	public void removeStateListener()
	{
		if(callback!=null)
			callback = null;
	}
	
	public void reset()
	{
		final int NI_WIDTH = arrBmpAnimation[niLv][niFrame].getWidth();
		rectPosition.left = Main.getScreenX() + (Main.getScreenWidth() - NI_WIDTH) / 2;
		rectPosition.right = rectPosition.left + NI_WIDTH ;
		
		niLv = 0;
		strLv = STR_TEXT_LV + (niLv + 1);
		
		niScore = 0;
		strScore = STR_TEXT_SCORE + niScore;
		pScore.x = Main.getScreenX() + Main.getScreenWidth() - 5 - 
				(int)paintText.measureText(STR_TEXT_SCORE + niScore);
	
		setState(false,true);
		
		niHp = NI_HP_BAR_WIDTH;
	}
	
	public void onDraw(Canvas canvas)
	{
		canvas.drawBitmap(arrBmpAnimation[niLv][niFrame],rectPosition.left,rectPosition.top,null);
		if (  niLv > 0 && niHp!=NI_HP_BAR_WIDTH )
		{
			paintHpBar.setColor(arrNIHpColor[niLv-1]);
			canvas.drawRect(rectHpBar, paintHpBar);
		} 
		paintHpBar.setColor(arrNIHpColor[niLv]);
		canvas.drawRect(rectHpBar.left,rectHpBar.top,rectHpBar.left+niHp,rectHpBar.bottom, paintHpBar);
		canvas.drawRect(rectHpBar, paintHpBarBorder);
		canvas.drawText(strLv, pLv.x, pLv.y, paintText);
		canvas.drawText(strScore, pScore.x, pScore.y, paintText);
	
		face.onDraw(canvas);
	}
	
	public void updateScore(int niValue)
	{
		niScore += niValue;
		if(niScore < 0)
		{
			niScore = 0;
		}
		strScore = STR_TEXT_SCORE + niScore;
		pScore.x = Main.getScreenX() + Main.getScreenWidth() - 5 - (int)paintText.measureText(STR_TEXT_SCORE + niScore);
	}
	
	private void moveLeft()
	{
		niFrame++;
		if(niFrame == NI_FRAME_MAX/2)
			niFrame = 0;
		
		rectPosition.left -= (NI_SPEED_BASIC + niLv);
		rectPosition.right -= (NI_SPEED_BASIC + niLv);
		
		if(rectPosition.left < Main.getScreenX())
		{
			rectPosition.left = Main.getScreenX();
			rectPosition.right = rectPosition.left + arrBmpAnimation[niLv][niFrame].getWidth();
		}
	}
	
	private void moveRight()
	{
		niFrame++;
		if(niFrame == NI_FRAME_MAX)
			niFrame = NI_FRAME_MAX / 2;
		
		rectPosition.left += (NI_SPEED_BASIC + niLv) ;
		rectPosition.right += (NI_SPEED_BASIC + niLv);
		
		if(rectPosition.right > Main.getScreenX() + Main.getScreenWidth())
		{
			rectPosition.right = Main.getScreenX() + Main.getScreenWidth();
			rectPosition.left = rectPosition.right - arrBmpAnimation[niLv][niFrame].getWidth();
		}
	}

	public void setState(boolean isMoving, boolean isLeft)
	{
		if(isMoving)
			niFrame = isLeft ? 1: 4;
		else
			niFrame = isLeft ? 0: 3;
		
		this.isMoving = isMoving;
		this.isLeft = isLeft;
	}
	
	public boolean lvUp()
	{
		if(niLv < NI_LV_MAX -1)
		{
			niLv++;
			strLv = STR_TEXT_LV + (niLv + 1 );
			return true;
		}
		return false;
	}
	
	public void addHp(int niValue)
	{
		niHp += niValue;
		if(niHp > NI_HP_BAR_WIDTH)
		{
			if(lvUp())
			{
				niHp = niHp - NI_HP_BAR_WIDTH;
			}
			else
			{
				niHp = NI_HP_BAR_WIDTH;
			}
		}
	}
	
	public void hurt(int niValue)
	{
		niHp -= niValue;
		if (  niHp <= 0  ) 
		{
			niLv--;
			if(niLv<0)
			{
				niHp = 0;
				niLv = 0;
				gameover();
			}
			else
			niHp = NI_HP_BAR_WIDTH;
			
			strLv = STR_TEXT_LV + (niLv + 1 );
		} 
	}
	
	private void gameover()
	{
		if(callback != null)
			callback.notityGameOver(niScore);
	}

	private void logic()
	{
		if(isMoving)
		{
			if(isLeft)
			{
				moveLeft();
			}
			else
			{
				moveRight();
			}
		}
	}
	
	public int getUpFree()
	{
		return niHp;
	}
	
	public Rect getRect()
	{
		return rectPosition;
	}
	
	public boolean stopAutoHurt(int niValue)
	{
		if(niStopAutoHurtValue != 0)
			return false;
		
		niStopAutoHurtValue = 10 * niValue ;
		return true;
	}
	
	public void propDeal(int niPropType)
	{
		face.start(niPropType, rectPosition);
		switch(niPropType)
		{
		case Prop.NI_TYPE_0 :
			addHp(30);
			break;
		case Prop.NI_TYPE_1 :
			updateScore(50);
			break;
		case Prop.NI_TYPE_2 :
			stopAutoHurt(5);
			break;
		case Prop.NI_TYPE_3 :
			if(!lvUp())
			addHp(Player.NI_HP_BAR_WIDTH);
			break;
		case Prop.NI_TYPE_4 :
			hurt(30);
			break;
		case Prop.NI_TYPE_5 :
			updateScore(-50);
			break;
		case Prop.NI_TYPE_6 :
			hurt(getUpFree());
			break;
		}
	}
	
	public void start()
	{
		if(!isThread)
		{
			isThread = true;
			new Thread(new LogicMonitor()).start();
			
			timerUpAutoHurt = new Timer();
			timerUpAutoHurt.schedule(new HpAutoHurtMonitor(), 3000, NI_HP_AUTO_HURT_ROTATE);
		}
	}
	
	public void close()
	{
		isThread = false;
		if(timerUpAutoHurt != null)
		{
			timerUpAutoHurt.cancel();
			timerUpAutoHurt = null;
		}
	}
	
	private class LogicMonitor implements Runnable
	{
		public void run()
		{
			while(isThread)
			{
				try{Thread.sleep(65);} catch (InterruptedException e){}
				logic();
			}
		}
	}
	
	private class HpAutoHurtMonitor extends TimerTask
	{
		@Override
		public void run()
		{
			if(niStopAutoHurtValue == 0)
				hurt(1);
			else
				niStopAutoHurtValue --;
		}
	}
}
