package com.planal.course07.game;

import java.util.Timer;
import java.util.TimerTask;

import com.planal.course07.main.LoadResourceListener;
import com.planal.course07.main.Main;
import com.planal.course07.tools.Tools;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Point;

public class StartView
{
	private Bitmap bmpBackground1 , bmpBackground2;
	private Bitmap bmpPressAnying;
	private Point pBackground;
	private Point pLoading;
	private Point pPressAnying;
	private Paint paintBackground;
	private Timer timerLoading ;
	private Bitmap[] arrBmpLoading;
	private LoadResourceListener listener;
	
	private int niFrame;
	private int isPressAnyingCount;
	private boolean isPressAnying;
	
	public StartView(LoadResourceListener listener)
	{
		this.listener = listener;
		arrBmpLoading = Tools.readBitmapFolderFromAssets("system/loading");
		bmpPressAnying = Tools.readImage(Main.getAssetManager(), "system/press.png");
		pLoading = new Point(
				Main.getScreenX() + (Main.getScreenWidth() - arrBmpLoading[0].getWidth())/2,
				Main.getScreenY() + (Main.getScreenHeight() - arrBmpLoading[0].getHeight())/2
				);
		
		bmpBackground1 = Tools.readImage(Main.getAssetManager(), "system/start1.png"); 
		bmpBackground2 = Tools.readImage(Main.getAssetManager(), "system/start2.png"); 
	
		pBackground = new Point(
			Main.getScreenX() + (Main.getScreenWidth() - bmpBackground1.getWidth())/2,
			Main.getScreenY() + (Main.getScreenHeight() - bmpBackground1.getHeight())/2
		);
		
		pPressAnying = new Point(
				Main.getScreenX() + (Main.getScreenWidth() - bmpPressAnying.getWidth())/2,
				Main.getScreenY() + Main.getScreenHeight() - bmpPressAnying.getHeight() * 2
			);
		
		paintBackground = new Paint(); 
		paintBackground.setAlpha(0);
	}
	
	public void onDraw(Canvas canvas)
	{
		canvas.drawBitmap(bmpBackground1, pBackground.x,pBackground.y, null);
		canvas.drawBitmap(bmpBackground2, pBackground.x,pBackground.y, paintBackground);
		
		if(isPressAnying)
		{
			if(isPressAnyingCount % 3 == 0)
				canvas.drawBitmap(bmpPressAnying,pPressAnying.x,pPressAnying.y,null);
		}
		else
			canvas.drawBitmap(arrBmpLoading[niFrame], pLoading.x, pLoading.y, null);
	}
	
	private void logic()
	{
		int niAlpha = paintBackground.getAlpha();
		if(niAlpha != 255)
		{
			int niAlphaValue = niAlpha + 1;
			if(niAlphaValue > 255)
				niAlphaValue = 255;
			paintBackground.setAlpha(niAlphaValue);
		}
		
		if(isPressAnying)
			isPressAnyingCount ++;
		else
		{
			++niFrame;
			if(niFrame == arrBmpLoading.length)
				niFrame = 0;	
		}

	}
	
	public boolean isStartGameEnable()
	{
		return isPressAnying;
	}
	
	public void start()
	{
		if(timerLoading == null)
		{
			timerLoading = new Timer();
			timerLoading.schedule(new LoadingAnimationMonitor(), 10, 40);
		
			new Thread(new Runnable()
			{
				public void run()
				{
					try{Thread.sleep(2000);} catch (InterruptedException e){}
					isPressAnying = listener.loadResource();
				}
			}).start();
		}
	}
	
	public void close()
	{
		if(timerLoading != null)
		{
			timerLoading.cancel();
			timerLoading = null;
		}
	}
	
	private class LoadingAnimationMonitor extends TimerTask
	{
		public void run()
		{
			logic();
		}
		
	}
}
