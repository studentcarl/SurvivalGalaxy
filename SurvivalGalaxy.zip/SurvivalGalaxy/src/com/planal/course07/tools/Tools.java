package com.planal.course07.tools;

import java.io.IOException;
import java.util.Random;

import android.content.res.AssetManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Rect;
import android.util.Log;

import com.planal.course07.main.Main;

public class Tools
{
	private static final String STR_TAG = "System.out";
	private static final Random RANDOM = new Random();
	
	public static final Bitmap readImage(AssetManager am,String strFileName)
	{
		Bitmap bmp = null;
		try
		{
			bmp = BitmapFactory.decodeStream(am.open(strFileName));
		} catch (IOException e)
		{
			logError("read image error :"+strFileName);
		}
		return bmp;
	}
	
	public static final Bitmap[] readBitmapFolderFromAssets(String strDir)
	{
		String[] arrStrFileName = null;
		try
		{
			arrStrFileName = Main.getAssetManager().list(strDir);
		} catch (IOException e)
		{
			Tools.logError(strDir+" error");
		}
		if(arrStrFileName.length == 0)
		{
			return null;
		}
		Bitmap[] arrBmp = new Bitmap[arrStrFileName.length];
		for (int i = 0; i < arrBmp.length; i++)
		{
			arrBmp[i] = Tools.readImage(Main.getAssetManager(), strDir+"/"+arrStrFileName[i]);
		}
		return arrBmp;
	}
	
	public static final void logInfo(String strInfo)
	{
		Log.i(STR_TAG,strInfo);
	}
	
	public static final void logError(String strInfo)
	{
		Log.i(STR_TAG,strInfo);
	}
	
	public static final int getRandom(int niMin,int niMax)
	{
		return niMin + RANDOM.nextInt(niMax-niMin);
	}
	
	public static final boolean collideWith(int niX,int niY,Rect rect)
	{
		return !(niX < rect.left || niX > rect.right||niY < rect.top||niY > rect.bottom);
	}
}
